package com.Calculate.Calculator;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.lang.Math;
@Controller
public class CalculatorController {
    @GetMapping("/calculate")
    public String calculatorForm(Model model) {
        model.addAttribute("calculate", new Calculate());
        return "calculate";
    }

    @PostMapping("/calculate")
    public String calculatorSubmit(@ModelAttribute Calculate calculate, Model model) {
        calculate.setPrzekatna((calculate.obliczPrzekatna(calculate.getBok(), calculate.getDrugiBok())));
        model.addAttribute("calculate", calculate);
        return "calculateResult";
    }
}
