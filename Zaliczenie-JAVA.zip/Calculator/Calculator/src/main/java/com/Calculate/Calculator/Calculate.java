package com.Calculate.Calculator;

public class Calculate {
    private double Bok;
    private double drugiBok;
    private double Przekatna;

    public double getBok(){
        return Bok;
    }
    public void setBok(double Bok){
        this.Bok = Bok;
    }
    public double getDrugiBok(){
        return drugiBok;
    }
    public void setDrugiBok(double drugiBok){
        this.drugiBok = drugiBok;
    }
    public double getPrzekatna(){
        return Przekatna;
    }
    public void setPrzekatna(double Przekatna){
        this.Przekatna = Przekatna;
    }
    public double obliczPrzekatna(double Bok, double drugiBok) {
        return (Math.sqrt(Math.pow(Bok, 2) + Math.pow(drugiBok, 2)));
    }
}
